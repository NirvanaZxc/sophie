module.exports = {
  extends: [
    'stylelint-config-rational-order',
    'stylelint-stylus/standard'
  ],
  rules: {
    'stylus/pythonic': 'never'
  }
}
